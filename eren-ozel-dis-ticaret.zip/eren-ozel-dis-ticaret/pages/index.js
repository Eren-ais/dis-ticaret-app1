import { useState } from "react";

export default function Home() {
  const [search, setSearch] = useState("");
  const [results, setResults] = useState([]);

  const demoData = [
    {
      gtip: "870850",
      firma: "Tipped Axles Ltd",
      ülke: "İngiltere",
      telefon: "+44 20 7946 0990",
      email: "info@tippedaxles.co.uk",
      whatsapp: "+44 7392 123456"
    },
    {
      gtip: "870850",
      firma: "Autoparts Mexico",
      ülke: "Meksika",
      telefon: "+52 55 1234 5678",
      email: "ventas@autopartsmx.mx",
      whatsapp: "+52 1 555 123 4567"
    },
    {
      gtip: "392690",
      firma: "Shanghai Plastics",
      ülke: "Çin",
      telefon: "+86 21 6789 1234",
      email: "contact@shplast.cn",
      whatsapp: "+86 138 00138000"
    }
  ];

  const handleSearch = () => {
    const filtered = demoData.filter(item =>
      item.gtip.includes(search) ||
      item.firma.toLowerCase().includes(search.toLowerCase()) ||
      item.ülke.toLowerCase().includes(search.toLowerCase())
    );
    setResults(filtered);
  };

  return (
    <div style={{ padding: "30px", fontFamily: "Arial" }}>
      <h1>Eren Özel Dış Ticaret Uygulaması</h1>
      <p>GTIP kodu, firma adı veya ülkeye göre arama yapabilirsiniz.</p>

      <input
        type="text"
        placeholder="GTIP/Firma/Ülke"
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        style={{ padding: "10px", width: "300px", marginRight: "10px" }}
      />
      <button onClick={handleSearch} style={{ padding: "10px 20px" }}>Ara</button>

      <div style={{ marginTop: "30px" }}>
        {results.length > 0 ? (
          results.map((item, i) => (
            <div key={i} style={{ marginBottom: "20px", borderBottom: "1px solid #ccc", paddingBottom: "10px" }}>
              <h3>{item.firma} ({item.ülke})</h3>
              <p>📦 GTIP: {item.gtip}</p>
              <p>📞 Telefon: {item.telefon}</p>
              <p>📧 E-Posta: {item.email}</p>
              <p>💬 WhatsApp: {item.whatsapp}</p>
            </div>
          ))
        ) : (
          <p>Sonuç bulunamadı.</p>
        )}
      </div>
    </div>
  );
}
